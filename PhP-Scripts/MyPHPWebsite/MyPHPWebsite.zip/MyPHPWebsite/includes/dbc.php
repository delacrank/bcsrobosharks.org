<?php
 $con = mysql_connect("localhost", "jariasmy_410rdo", "Assswipe1") or die(mysql_error());
 $db_selected = mysql_select_db("jariasmy_gameSite", $con);
 //echo "Connected to MySQL<br />";
 ?> 